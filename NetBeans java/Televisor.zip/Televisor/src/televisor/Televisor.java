/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package televisor;

/**
 *
 * @author Aluno
 */
public class Televisor {
   private int volume ;
    
    
    
public void Televisor(){
    volume = 0;
}

public void aumentaVolume(){
if (volume < 40){
    volume = volume + 1;
}

}

public void diminuiVolume(){
if (volume > 0){
    volume = volume - 1;
}
}

public void alteraVolume(int valor){


if (volume > 0 && volume < 40){
    volume = valor;
}
}

public String retornaVolume(){
return "Volume: "+ volume;
}

}