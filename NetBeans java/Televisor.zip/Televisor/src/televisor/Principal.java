/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package televisor;

/**
 *
 * @author Aluno
 */
public class Principal {
    public static void main(String[] args){
       Televisor t = new Televisor();
        
       
       t.alteraVolume(33);
       t.aumentaVolume();
       t.diminuiVolume();
       t.aumentaVolume();
       System.out.println(t.retornaVolume());
       
    }
}
